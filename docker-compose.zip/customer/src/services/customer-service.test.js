describe("Customer Service", () => {
  it("should return a list of customers", async () => {});
});
