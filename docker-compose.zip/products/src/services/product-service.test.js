describe("Product Service", () => {
  it("should return a list of products", async () => {});
});
