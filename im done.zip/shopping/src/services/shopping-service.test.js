describe("ShoppingService", () => {
  describe("PlaceOrder", () => {
    test("validate user inputs", () => {});
    test("validate response", async () => {});
  });
});
