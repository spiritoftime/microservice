describe("ProductService", () => {
  describe("CreateProduct", () => {
    test("validate user inputs", () => {});
    test("validate response", async () => {});
  });
});
