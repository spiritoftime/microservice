describe("CustomerService", () => {
  // which function we are testing
  describe("SignIn", () => {
    test("validate user inputs", () => {});
    test("validate response", async () => {});
  });
});
